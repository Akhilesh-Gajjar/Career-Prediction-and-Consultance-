

<div class="w3-top">
  <div class="w3-bar w3-green w3-card w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-red" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="demoproglog.php" class="w3-bar-item w3-button w3-padding-large w3-hover-white">Home</a>
    <a href="apttestmain.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Aptitude test</a>
    <a href="ScholarshipSchemes3.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Scholarship schemes</a>
    <a href="feedback.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Feedback</a>
    <a href="FAQs2.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">FAQs</a>
    <a href="slink.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Counselling</a>
    <a href="careerscope.php" class="w3-bar-item w3-button  w3-hide-small w3-padding-large w3-hover-white">CareerScope</a>
    <a href="careerprep1.php" class="w3-bar-item w3-button  w3-hide-small w3-padding-large w3-hover-white">CarrerPrepTips</a>
    <a href="logout.php" class="w3-bar-item w3-button w3-black w3-hide-small w3-padding-large w3-hover-white" style="float:right;">Log Out</a>
</div>
